#!/usr/bin/env python3
"""
excel_to_jsonld.py
==================
Converts a structured Excel checklist + an OWL ontology into:
  1.  A JSON-LD document whose @graph mirrors the ontology's class/property
      structure (nested graph, hasPart / partOf resolved as object links).
  2.  A Cypher import script ready for Neo4j.

Usage
-----
    python excel_to_jsonld.py <excel_file> <owl_file>
                              [--companion <companion_ttl>]
                              [--output-jsonld <path>]
                              [--output-cypher <path>]

Design
------
Each worksheet represents one OWL class.  The first row contains property
names (column headers).  A sheet may be:
  - "record-per-row"  →  each row is one instance (Study, Person …)
  - "transposed"      →  row-1 = property names, row-2 = single values
                         (detected when column A header is "property" and
                          column A value is "value").

Special column names
  hasPart / partOf    →  ObjectProperty; value is a semicolon-separated
                         list of IDs referencing rows in another sheet.
  Person:hasXxx       →  a property from an external vocabulary (schema.org /
                         foaf); mapped by the companion ontology.

All class and property URIs are looked up in the merged OWL graph
(base ontology + optional companion).  Unknown column headers are kept as
hydata: terms so no data is silently dropped.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import uuid
from collections import defaultdict
from datetime import datetime, date
from pathlib import Path
from typing import Any

import openpyxl
from rdflib import Graph, Namespace, OWL, RDF, RDFS, URIRef, Literal
from rdflib.namespace import XSD

# ---------------------------------------------------------------------------
# Namespaces
# ---------------------------------------------------------------------------
PPEO    = Namespace("http://purl.org/ppeo/PPEO.owl#")
HYDATA  = Namespace("http://purl.org/hydata/ontology#")
SCHEMA  = Namespace("https://schema.org/")
FOAF    = Namespace("http://xmlns.com/foaf/0.1/")

BASE_PREFIXES = {
    "ppeo":    str(PPEO),
    "hydata":  str(HYDATA),
    "schema":  str(SCHEMA),
    "foaf":    str(FOAF),
    "xsd":     str(XSD),
    "rdf":     "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    "rdfs":    "http://www.w3.org/2000/01/rdf-schema#",
    "owl":     "http://www.w3.org/2002/07/owl#",
}

# Properties treated as object links (→ reference other named nodes)
OBJECT_LINK_PROPS = {"hasPart", "partOf", "derivesFrom",
                     "hasContactInstitution", "hasAffiliation",
                     "hasLocation", "hasCountry"}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _slug(text: str) -> str:
    """Create a simple URI-safe slug from free text."""
    return re.sub(r"[^A-Za-z0-9_\-]", "_", str(text).strip())


def _local(uri: str | URIRef) -> str:
    """Return the local name of a URI (after # or last /)."""
    s = str(uri)
    return s.split("#")[-1] if "#" in s else s.rsplit("/", 1)[-1]


def _parse_date(val: Any) -> str | None:
    """Return an ISO date string or None."""
    if val is None:
        return None
    if isinstance(val, (datetime, date)):
        return val.strftime("%Y-%m-%d")
    try:
        # Excel may store dates as integers (days since 1899-12-30)
        ref = datetime(1899, 12, 30)
        d = ref + __import__("datetime").timedelta(days=int(val))
        return d.strftime("%Y-%m-%d")
    except Exception:
        return str(val).strip() or None


def _split_ids(raw: str) -> list[str]:
    """
    Split a semicolon- (or comma-) separated list of IDs.
    Handles messy entries like '2018_SEL;, 2019_WST; 2019_NRS'
    """
    if not raw:
        return []
    parts = re.split(r"[;,]+", str(raw))
    return [p.strip() for p in parts if p.strip()]


def _make_prefixed(local_name: str, ns: str = "ppeo") -> str:
    return f"{ns}:{local_name}"


# ---------------------------------------------------------------------------
# Ontology loader & property registry
# ---------------------------------------------------------------------------

class OntologyRegistry:
    """
    Merges one or more OWL/TTL graphs and builds lookup tables for:
      - class local-names  →  full URIs
      - property local-names  →  (full_URI, domain_local, range_local, prop_type)
      - column-mapping annotations from companion ontology
    """

    def __init__(self, *owl_paths: str | Path):
        self.g = Graph()
        for p in owl_paths:
            fmt = "turtle" if str(p).endswith(".ttl") else None
            self.g.parse(str(p), format=fmt)

        self._classes: dict[str, URIRef] = {}       # local_name  → URI
        self._props:   dict[str, dict]   = {}       # local_name  → info dict
        self._col_map: dict[str, dict[str, str]] = defaultdict(dict)
        # col_map[sheet_name][col_header] = prop_local_name

        self._build_class_index()
        self._build_property_index()
        self._build_column_map()

    # ------------------------------------------------------------------ index

    def _build_class_index(self):
        for cls in self.g.subjects(RDF.type, OWL.Class):
            if isinstance(cls, URIRef):
                ln = _local(cls)
                self._classes[ln.lower()] = cls

    def _build_property_index(self):
        prop_types = {
            OWL.DatatypeProperty: "DataProperty",
            OWL.ObjectProperty:   "ObjectProperty",
            OWL.AnnotationProperty: "AnnotationProperty",
        }
        for ptype, label in prop_types.items():
            for prop in self.g.subjects(RDF.type, ptype):
                if not isinstance(prop, URIRef):
                    continue
                ln = _local(prop)
                domain_uri = self.g.value(prop, RDFS.domain)
                range_uri  = self.g.value(prop, RDFS.range)
                self._props[ln.lower()] = {
                    "uri":    prop,
                    "local":  ln,
                    "type":   label,
                    "domain": _local(domain_uri) if domain_uri and isinstance(domain_uri, URIRef) else None,
                    "range":  _local(range_uri)  if range_uri  and isinstance(range_uri,  URIRef) else None,
                }

    def _build_column_map(self):
        """
        Parse hydata:columnMappings annotations.
        Format: "Sheet^^ColumnHeader^^PropertyLocalName"
        """
        cm_pred = HYDATA.columnMappings
        for _, _, obj in self.g.triples((None, cm_pred, None)):
            parts = str(obj).split("^^")
            if len(parts) == 3:
                sheet, col, prop = parts
                self._col_map[sheet][col] = prop

    # ------------------------------------------------------------------ query

    def resolve_class(self, name: str) -> URIRef | None:
        return self._classes.get(name.lower())

    def resolve_property(self, name: str) -> dict | None:
        return self._props.get(name.lower())

    def column_to_property(self, sheet: str, col_header: str) -> str:
        """
        Return the ontology local-name for a column header.
        Priority: companion mapping → exact OWL match → camelCase OWL fuzzy → raw header.
        """
        # 1. companion explicit mapping
        if sheet in self._col_map and col_header in self._col_map[sheet]:
            return self._col_map[sheet][col_header]

        # 2. exact match in property index
        if col_header.lower() in self._props:
            return self._props[col_header.lower()]["local"]

        # 3. strip "Person:" prefix
        stripped = re.sub(r"^[A-Za-z]+:", "", col_header)
        if stripped.lower() in self._props:
            return self._props[stripped.lower()]["local"]

        # 4. camelCase collapse (e.g., "Public release date" → "publicReleaseDate")
        cc = re.sub(r"\s+(.)", lambda m: m.group(1).upper(), col_header.strip()).replace(" ", "")
        cc = cc[0].lower() + cc[1:] if cc else cc
        if cc.lower() in self._props:
            return self._props[cc.lower()]["local"]

        # 5. unknown → coin a hydata: term
        safe = _slug(col_header)
        return f"hydata:{safe}"

    def property_info(self, local_name: str) -> dict:
        """Return property metadata dict, falling back to a default."""
        key = local_name.replace("hydata:", "").lower()
        return self._props.get(key, {"local": local_name, "type": "DataProperty",
                                      "domain": None, "range": None})

    def class_uri(self, sheet: str) -> str:
        """Return a curie for the class corresponding to a sheet."""
        uri = self.resolve_class(sheet)
        if uri:
            ln = _local(uri)
            if str(uri).startswith(str(PPEO)):
                return f"ppeo:{ln}"
            if str(uri).startswith(str(HYDATA)):
                return f"hydata:{ln}"
        return f"hydata:{sheet}"


# ---------------------------------------------------------------------------
# Excel reader
# ---------------------------------------------------------------------------

class ExcelReader:
    """
    Reads an xlsx workbook and returns sheets as lists of {col: value} dicts.
    Handles the two sheet layouts:
      - transposed  (investigation-like): row1=headers, row2=values
      - record-per-row: row1=headers, row2..N=data rows
    """

    def __init__(self, path: str | Path):
        self.wb = openpyxl.load_workbook(str(path))

    @property
    def sheet_names(self) -> list[str]:
        return self.wb.sheetnames

    def read_sheet(self, name: str) -> tuple[list[dict], bool]:
        """
        Returns (rows, is_transposed).
        Each row is a dict {header: value} with None keys stripped.
        """
        ws = self.wb[name]
        all_rows = list(ws.iter_rows(values_only=True))
        if not all_rows:
            return [], False

        headers = [h for h in all_rows[0]]
        data_rows = all_rows[1:]

        # Detect transposed format: first header cell is "property" (case-insensitive)
        is_transposed = (
            headers and headers[0] is not None
            and str(headers[0]).strip().lower() == "property"
            and data_rows
            and data_rows[0] and str(data_rows[0][0]).strip().lower() == "value"
        )

        result = []
        if is_transposed:
            # Single logical row: zip headers → values (skip index columns)
            row_dict = {}
            for h, v in zip(headers[1:], data_rows[0][1:]):
                if h is not None and v is not None:
                    row_dict[str(h).strip()] = v
            if row_dict:
                result.append(row_dict)
        else:
            for row in data_rows:
                row_dict = {}
                for h, v in zip(headers, row):
                    if h is not None and v is not None:
                        row_dict[str(h).strip()] = v
                if row_dict:
                    result.append(row_dict)

        return result, is_transposed


# ---------------------------------------------------------------------------
# JSON-LD builder
# ---------------------------------------------------------------------------

# Maps sheet names to ID column names
ID_COLUMNS: dict[str, str] = {
    "investigation": "Investigation unique ID",
    "study":         "hasID",
    "person":        "Person:hasORCID",   # fallback: generated UUID
}

# Date-like property names (will be converted to ISO date strings)
DATE_PROPS = {"hassubmissiondate", "publicreleasedate", "hasstartingdate",
              "hasendingdate", "hasstartdatetime", "hasenddatetime"}


def _node_id(sheet: str, row: dict, idx: int) -> str:
    """
    Derive a stable node @id from the row.
    Uses the known ID column for the sheet, or generates a UUID.
    """
    id_col = ID_COLUMNS.get(sheet.lower())
    if id_col and id_col in row:
        return str(row[id_col]).strip()
    # fallback: try any column containing "ID" or "id" in its name
    for k, v in row.items():
        if "id" in k.lower() and v:
            return str(v).strip()
    return f"urn:uuid:{uuid.uuid4()}"


def _value_for_jsonld(prop_local: str, raw_val: Any) -> Any:
    """
    Coerce a raw cell value to an appropriate JSON-LD value representation.
    Date cells come from openpyxl as datetime objects or as Excel serial ints.
    """
    if raw_val is None:
        return None

    key = prop_local.lower().replace("hydata:", "")

    if key in DATE_PROPS or isinstance(raw_val, (datetime, date)):
        ds = _parse_date(raw_val)
        if ds:
            return {"@type": "xsd:date", "@value": ds}

    if isinstance(raw_val, float) and raw_val == int(raw_val):
        # Could be a year or serial date
        if key in DATE_PROPS:
            ds = _parse_date(int(raw_val))
            if ds:
                return {"@type": "xsd:date", "@value": ds}
        return int(raw_val)

    if isinstance(raw_val, (int, float, bool)):
        return raw_val

    return str(raw_val).strip()


def build_jsonld(
    excel: ExcelReader,
    registry: OntologyRegistry,
) -> dict:
    """
    Main builder: iterates all sheets, validates classes, builds the @graph.
    """
    context = dict(BASE_PREFIXES)
    graph: list[dict] = []

    # We need a two-pass approach so that object links (hasPart / partOf)
    # can reference nodes defined in other sheets.
    # Pass 1: build raw node dicts keyed by node @id
    # Pass 2: resolve object-link properties into {"@id": …} references

    # Raw nodes:  sheet_name → { node_id → node_dict }
    all_nodes: dict[str, dict[str, dict]] = {}

    for sheet_name in excel.sheet_names:
        rows, is_transposed = excel.read_sheet(sheet_name)
        if not rows:
            print(f"  [SKIP] sheet '{sheet_name}' is empty.", file=sys.stderr)
            continue

        # Validate class
        class_uri = registry.resolve_class(sheet_name)
        if class_uri is None:
            print(f"  [WARN] Class '{sheet_name}' not found in ontology; "
                  f"using hydata:{sheet_name} as fallback.", file=sys.stderr)
        class_curie = registry.class_uri(sheet_name)

        sheet_nodes: dict[str, dict] = {}
        for idx, row in enumerate(rows):
            node_id = _node_id(sheet_name, row, idx)
            node: dict[str, Any] = {
                "@id":   node_id,
                "@type": class_curie,
            }

            for col_header, raw_val in row.items():
                prop_local = registry.column_to_property(sheet_name, col_header)
                pinfo      = registry.property_info(prop_local)

                # skip if value is empty
                if raw_val is None or str(raw_val).strip() == "":
                    continue

                # Object-link property → store raw string; resolve in pass 2
                if (prop_local in OBJECT_LINK_PROPS
                        or (pinfo.get("type") == "ObjectProperty"
                            and prop_local not in {"hasExperimentalDesign"})):
                    # store as raw string list for later resolution
                    ids = _split_ids(str(raw_val))
                    if ids:
                        node[f"_raw_link_{prop_local}"] = ids
                    continue

                val = _value_for_jsonld(prop_local, raw_val)
                if val is None:
                    continue

                # Use a prefixed property name
                if ":" not in prop_local:
                    # decide namespace: ppeo or hydata
                    if registry.resolve_property(prop_local):
                        pkey = f"ppeo:{prop_local}"
                    else:
                        pkey = f"hydata:{prop_local}"
                else:
                    pkey = prop_local

                node[pkey] = val

            sheet_nodes[node_id] = node
        all_nodes[sheet_name] = sheet_nodes

    # ------------------------------------------------------------------ pass 2
    # Resolve object links; build the final graph

    def _resolve_links(node: dict, all_nodes: dict) -> dict:
        resolved = {k: v for k, v in node.items() if not k.startswith("_raw_link_")}
        for k, v in node.items():
            if k.startswith("_raw_link_"):
                prop = k[len("_raw_link_"):]
                if ":" not in prop:
                    pkey = f"ppeo:{prop}" if registry.resolve_property(prop) else f"hydata:{prop}"
                else:
                    pkey = prop
                refs = [{"@id": rid} for rid in v]
                resolved[pkey] = refs if len(refs) > 1 else refs[0]
        return resolved

    # Build flat list, with Investigation's @graph embedding Studies
    inv_nodes = all_nodes.get("Investigation", {})
    study_nodes = all_nodes.get("Study", {})
    person_nodes = all_nodes.get("Person", {})

    # Build study node list (resolved)
    study_list = [_resolve_links(n, all_nodes) for n in study_nodes.values()]

    # Build person node list → also contains partOf links to studies
    person_list = [_resolve_links(n, all_nodes) for n in person_nodes.values()]

    # Build investigation node(s) and embed studies via ppeo:hasPart
    for inv_id, inv_node in inv_nodes.items():
        inv_resolved = _resolve_links(inv_node, all_nodes)
        # Ensure hasPart points to study list
        if study_list:
            inv_resolved["ppeo:hasPart"] = [{"@id": s["@id"]} for s in study_list]
        graph.append(inv_resolved)

    graph.extend(study_list)
    graph.extend(person_list)

    return {
        "@context":  context,
        "@graph":    graph,
    }


# ---------------------------------------------------------------------------
# Cypher generator
# ---------------------------------------------------------------------------

def _cypher_label(curie: str) -> str:
    """Convert 'ppeo:study' → 'study' as a Neo4j label."""
    return curie.split(":")[-1].capitalize()


def _cypher_value(val: Any) -> str:
    """Render a JSON-LD value as a Cypher literal."""
    if isinstance(val, dict):
        # {"@type": "xsd:date", "@value": "2024-07-05"}  or  {"@id": "..."}
        v = val.get("@value", val.get("@id", ""))
        return f'"{_cypher_escape(str(v))}"'
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    if isinstance(val, str):
        return f'"{_cypher_escape(val)}"'
    return f'"{_cypher_escape(str(val))}"'


def _cypher_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _prop_name(pkey: str) -> str:
    """'ppeo:hasName' → 'hasName'  (drop namespace prefix)."""
    return pkey.split(":")[-1]


RELATIONSHIP_PROPS = {"hasPart", "partOf", "derivesFrom", "hasAffiliation",
                      "hasLocation", "hasCountry", "hasContactInstitution"}


def build_cypher(jsonld: dict) -> str:
    lines: list[str] = [
        "// ============================================================",
        "// AUTO-GENERATED Cypher import script",
        "// Target: Neo4j  |  Source: excel_to_jsonld.py",
        "// ============================================================",
        "",
        "// Constraints (run once)",
        "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Investigation) REQUIRE n.id IS UNIQUE;",
        "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Study)         REQUIRE n.id IS UNIQUE;",
        "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Person)        REQUIRE n.id IS UNIQUE;",
        "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Institution)   REQUIRE n.name IS UNIQUE;",
        "",
        "// ---- Nodes ----",
        "",
    ]

    rel_queue: list[tuple[str, str, str, str]] = []
    # (from_id, to_id, rel_type, from_label)

    for node in jsonld.get("@graph", []):
        node_id  = node.get("@id", "")
        node_type = _cypher_label(node.get("@type", "Entity"))
        props: dict[str, Any] = {}

        for k, v in node.items():
            if k in ("@id", "@type"):
                continue
            pname = _prop_name(k)

            # Object-link properties → queue as relationship
            if pname in RELATIONSHIP_PROPS:
                targets = v if isinstance(v, list) else [v]
                for t in targets:
                    if isinstance(t, dict) and "@id" in t:
                        rel_queue.append((node_id, t["@id"], pname.upper(), node_type))
                continue

            # Multi-value lists that are NOT object links → serialize as string
            if isinstance(v, list):
                props[pname] = json.dumps([
                    vv.get("@value", vv.get("@id", str(vv))) if isinstance(vv, dict) else vv
                    for vv in v
                ])
                continue

            if isinstance(v, dict):
                if "@id" in v:
                    rel_queue.append((node_id, v["@id"], pname.upper(), node_type))
                    continue
                if "@value" in v:
                    props[pname] = v["@value"]
                continue

            props[pname] = v

        # Primary key defaults
        props.setdefault("id", node_id)

        prop_str = ", ".join(
            f"{p}: {_cypher_value(val)}" for p, val in props.items()
        )
        lines.append(f"MERGE (n:{node_type} {{id: {_cypher_value(node_id)}}}) SET n += {{{prop_str}}};")

    lines += ["", "// ---- Relationships ----", ""]

    # Helper to pick the right lookup key per label
    def _lookup_key(label: str) -> str:
        return "id"  # all our nodes use id as key

    for from_id, to_id, rel_type, from_label in rel_queue:
        # Try to determine the target label from the node type stored in graph
        to_label = "Entity"
        for node in jsonld.get("@graph", []):
            if node.get("@id") == to_id:
                to_label = _cypher_label(node.get("@type", "Entity"))
                break
        # For unresolved targets (e.g. institutions as literals) we create them
        if to_label == "Entity":
            # might be a Study or Institution id
            to_label = "Study"  # most common case for hasPart / partOf

        lines.append(
            f'MATCH (a:{from_label} {{id: "{_cypher_escape(from_id)}"}}) '
            f'MATCH (b:{to_label}  {{id: "{_cypher_escape(to_id)}" }}) '
            f'MERGE (a)-[:{rel_type}]->(b);'
        )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Convert an OWL-backed Excel checklist to JSON-LD + Cypher."
    )
    p.add_argument("excel_file",  help="Input .xlsx file")
    p.add_argument("owl_file",    help="Base OWL ontology (.owl / .ttl / .rdf)")
    p.add_argument(
        "--companion", "-c",
        default=None,
        help="Optional companion .ttl ontology (column mappings, extra terms)",
    )
    p.add_argument("--output-jsonld", "-j", default="output.jsonld",
                   help="Output JSON-LD file (default: output.jsonld)")
    p.add_argument("--output-cypher", "-q", default="output.cypher",
                   help="Output Cypher file  (default: output.cypher)")
    p.add_argument("--verbose", "-v", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()

    print(f"[1/4] Loading ontology: {args.owl_file}")
    owl_paths = [args.owl_file]
    if args.companion:
        print(f"      + companion:       {args.companion}")
        owl_paths.append(args.companion)

    registry = OntologyRegistry(*owl_paths)
    print(f"      Classes: {len(registry._classes)}   Properties: {len(registry._props)}")

    print(f"\n[2/4] Reading Excel: {args.excel_file}")
    excel = ExcelReader(args.excel_file)
    print(f"      Sheets: {excel.sheet_names}")

    print("\n[3/4] Validating sheets against ontology ...")
    for sheet in excel.sheet_names:
        uri = registry.resolve_class(sheet)
        if uri:
            print(f"      ✓  '{sheet}' → <{uri}>")
        else:
            print(f"      ⚠  '{sheet}' has no direct class in ontology "
                  "(will use hydata: fallback)")

    print("\n[4/4] Building JSON-LD ...")
    jsonld = build_jsonld(excel, registry)

    node_count = len(jsonld["@graph"])
    print(f"      Graph nodes: {node_count}")

    # --- write JSON-LD ---
    out_jld = Path(args.output_jsonld)
    out_jld.write_text(json.dumps(jsonld, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\n✅  JSON-LD written → {out_jld}")

    # --- write Cypher ---
    cypher = build_cypher(jsonld)
    out_cyp = Path(args.output_cypher)
    out_cyp.write_text(cypher, encoding="utf-8")
    print(f"✅  Cypher   written → {out_cyp}")

    # --- quick stats ---
    labels: dict[str, int] = defaultdict(int)
    for node in jsonld["@graph"]:
        labels[node.get("@type", "??")] += 1
    print("\n--- Node-type summary ---")
    for lbl, cnt in sorted(labels.items(), key=lambda x: -x[1]):
        print(f"  {lbl:30s}  {cnt}")


if __name__ == "__main__":
    main()
